<?php
namespace ClassFlowPro\Admin;

if (!defined('ABSPATH')) { exit; }

class Customers
{
    public static function render(): void
    {
        if (!current_user_can('manage_options')) return;
        $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : '';
        $user_id = isset($_GET['user_id']) ? (int) $_GET['user_id'] : 0;

        // Handle POST actions: save profile, credits, notes
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && check_admin_referer('cfp_customers_action')) {
            $do = sanitize_text_field($_POST['cfp_do'] ?? '');
            $uid = (int)($_POST['user_id'] ?? 0);
            if ($do === 'save_profile' && $uid) {
                update_user_meta($uid, 'cfp_phone', sanitize_text_field($_POST['cfp_phone'] ?? ''));
                update_user_meta($uid, 'cfp_dob', sanitize_text_field($_POST['cfp_dob'] ?? ''));
                update_user_meta($uid, 'cfp_emg_name', sanitize_text_field($_POST['cfp_emg_name'] ?? ''));
                update_user_meta($uid, 'cfp_emg_phone', sanitize_text_field($_POST['cfp_emg_phone'] ?? ''));
                update_user_meta($uid, 'cfp_medical', wp_kses_post($_POST['cfp_medical'] ?? ''));
                update_user_meta($uid, 'cfp_injuries', wp_kses_post($_POST['cfp_injuries'] ?? ''));
                echo '<div class="notice notice-success"><p>' . esc_html__('Profile saved.', 'classflow-pro') . '</p></div>';
                $action = 'view'; $user_id = $uid;
            } elseif ($do === 'adjust_credits' && $uid) {
                $delta = (int)($_POST['credits_delta'] ?? 0);
                if ($delta !== 0) {
                    if ($delta > 0) {
                        \ClassFlowPro\Packages\Manager::grant_package($uid, __('Manual Credit', 'classflow-pro'), $delta, 0, 'usd', null);
                    } else {
                        // consume credits by creating a negative grant (record only)
                        \ClassFlowPro\Packages\Manager::grant_package($uid, __('Adjustment', 'classflow-pro'), $delta, 0, 'usd', null);
                    }
                    echo '<div class="notice notice-success"><p>' . esc_html__('Credits updated.', 'classflow-pro') . '</p></div>';
                }
                $action = 'view'; $user_id = $uid;
            } elseif ($do === 'add_note' && $uid) {
                global $wpdb; $t=$wpdb->prefix.'cfp_customer_notes';
                $note = wp_kses_post($_POST['note'] ?? '');
                $visible = !empty($_POST['visible_to_user']) ? 1 : 0;
                if ($note) {
                    $wpdb->insert($t, [ 'user_id'=>$uid, 'note'=>$note, 'visible_to_user'=>$visible, 'created_by'=>get_current_user_id()?:null ], ['%d','%s','%d','%d']);
                    echo '<div class="notice notice-success"><p>' . esc_html__('Note added.', 'classflow-pro') . '</p></div>';
                }
                $action = 'view'; $user_id = $uid;
            }
        }

        echo '<div class="wrap">';
        echo '<h1>' . esc_html__('Customers', 'classflow-pro') . '</h1>';

        if ($action === 'view' && $user_id) {
            self::render_customer($user_id);
        } else {
            self::render_list();
        }
        echo '</div>';
    }

    private static function render_list(): void
    {
        $search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
        $paged = isset($_GET['paged']) ? max(1, (int)$_GET['paged']) : 1;
        $per_page = 20; $offset = ($paged-1)*$per_page;
        $args = [ 'role__in' => ['customer'], 'number' => $per_page, 'offset' => $offset, 'fields' => ['ID','display_name','user_email'] ];
        if ($search) { $args['search'] = '*' . esc_attr($search) . '*'; $args['search_columns'] = ['user_email','user_login','display_name']; }
        $users = get_users($args);
        $total = count_users()['avail_roles']['customer'] ?? 0;

        echo '<form method="get" class="search-form"><input type="hidden" name="page" value="classflow-pro-customers" />';
        echo '<p class="search-box">';
        echo '<label class="screen-reader-text" for="cfp-cust-search">' . esc_html__('Search Customers', 'classflow-pro') . '</label>';
        echo '<input type="search" id="cfp-cust-search" name="s" value="' . esc_attr($search) . '" /> ';
        submit_button(__('Search'), 'button', '', false);
        echo '</p></form>';

        echo '<table class="wp-list-table widefat fixed striped"><thead><tr>';
        echo '<th>' . esc_html__('Name', 'classflow-pro') . '</th>';
        echo '<th>' . esc_html__('Email', 'classflow-pro') . '</th>';
        echo '<th>' . esc_html__('Credits', 'classflow-pro') . '</th>';
        echo '<th>' . esc_html__('Actions', 'classflow-pro') . '</th>';
        echo '</tr></thead><tbody>';
        if (!$users) echo '<tr><td colspan="4">' . esc_html__('No customers found.', 'classflow-pro') . '</td></tr>';
        foreach ($users as $u) {
            $credits = \ClassFlowPro\Packages\Manager::get_user_credits((int)$u->ID);
            $view = esc_url(admin_url('admin.php?page=classflow-pro-customers&action=view&user_id=' . (int)$u->ID));
            echo '<tr>';
            echo '<td><strong><a href="' . $view . '">' . esc_html($u->display_name ?: ('#' . (int)$u->ID)) . '</a></strong></td>';
            echo '<td>' . esc_html($u->user_email) . '</td>';
            echo '<td>' . esc_html((string)$credits) . '</td>';
            echo '<td><a class="button" href="' . $view . '">' . esc_html__('Manage', 'classflow-pro') . '</a></td>';
            echo '</tr>';
        }
        echo '</tbody></table>';

        // Pagination
        $total_pages = (int) ceil($total / $per_page);
        if ($total_pages > 1) {
            echo '<div class="tablenav bottom"><div class="tablenav-pages">';
            echo paginate_links([
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'total' => $total_pages,
                'current' => $paged,
            ]);
            echo '</div></div>';
        }
    }

    private static function render_customer(int $user_id): void
    {
        $user = get_user_by('id', $user_id);
        if (!$user) { echo '<p>' . esc_html__('User not found.', 'classflow-pro') . '</p>'; return; }
        $credits = \ClassFlowPro\Packages\Manager::get_user_credits($user_id);
        $phone = get_user_meta($user_id, 'cfp_phone', true);
        $dob = get_user_meta($user_id, 'cfp_dob', true);
        $emg_name = get_user_meta($user_id, 'cfp_emg_name', true);
        $emg_phone = get_user_meta($user_id, 'cfp_emg_phone', true);
        $medical = get_user_meta($user_id, 'cfp_medical', true);
        $inj = get_user_meta($user_id, 'cfp_injuries', true);

        echo '<h2>' . esc_html($user->display_name ?: $user->user_email) . '</h2>';
        echo '<p><strong>' . esc_html__('Email:', 'classflow-pro') . '</strong> ' . esc_html($user->user_email) . ' &nbsp; <strong>' . esc_html__('Credits:', 'classflow-pro') . '</strong> ' . esc_html((string)$credits) . '</p>';

        echo '<h3>' . esc_html__('Contact & Profile', 'classflow-pro') . '</h3>';
        echo '<form method="post">';
        wp_nonce_field('cfp_customers_action');
        echo '<input type="hidden" name="cfp_do" value="save_profile" />';
        echo '<input type="hidden" name="user_id" value="' . esc_attr((string)$user_id) . '" />';
        echo '<table class="form-table"><tbody>';
        echo '<tr><th>' . esc_html__('Phone', 'classflow-pro') . '</th><td><input type="tel" name="cfp_phone" value="' . esc_attr((string)$phone) . '" class="regular-text" /></td></tr>';
        echo '<tr><th>' . esc_html__('Date of Birth', 'classflow-pro') . '</th><td><input type="date" name="cfp_dob" value="' . esc_attr((string)$dob) . '" /></td></tr>';
        echo '<tr><th>' . esc_html__('Emergency Contact Name', 'classflow-pro') . '</th><td><input type="text" name="cfp_emg_name" value="' . esc_attr((string)$emg_name) . '" class="regular-text" /></td></tr>';
        echo '<tr><th>' . esc_html__('Emergency Contact Phone', 'classflow-pro') . '</th><td><input type="tel" name="cfp_emg_phone" value="' . esc_attr((string)$emg_phone) . '" class="regular-text" /></td></tr>';
        echo '<tr><th>' . esc_html__('Medical Conditions', 'classflow-pro') . '</th><td><textarea name="cfp_medical" rows="3" class="large-text">' . esc_textarea((string)$medical) . '</textarea></td></tr>';
        echo '<tr><th>' . esc_html__('Injuries/Surgeries', 'classflow-pro') . '</th><td><textarea name="cfp_injuries" rows="3" class="large-text">' . esc_textarea((string)$inj) . '</textarea></td></tr>';
        echo '</tbody></table>';
        submit_button(__('Save Profile', 'classflow-pro'));
        echo '</form>';

        echo '<h3>' . esc_html__('Credits', 'classflow-pro') . '</h3>';
        echo '<form method="post" style="margin-bottom:16px;">';
        wp_nonce_field('cfp_customers_action');
        echo '<input type="hidden" name="cfp_do" value="adjust_credits" />';
        echo '<input type="hidden" name="user_id" value="' . esc_attr((string)$user_id) . '" />';
        echo '<label>' . esc_html__('Adjust by', 'classflow-pro') . ' <input type="number" name="credits_delta" value="1" step="1" class="small-text" /></label> ';
        submit_button(__('Apply'), 'secondary', '', false);
        echo '</form>';

        // Notes
        global $wpdb; $t=$wpdb->prefix.'cfp_customer_notes';
        $notes = $wpdb->get_results($wpdb->prepare("SELECT n.*, u.display_name AS author FROM $t n LEFT JOIN {$wpdb->users} u ON u.ID=n.created_by WHERE n.user_id=%d ORDER BY n.created_at DESC", $user_id), ARRAY_A);
        echo '<h3>' . esc_html__('Notes', 'classflow-pro') . '</h3>';
        echo '<form method="post" style="margin-bottom:10px;">';
        wp_nonce_field('cfp_customers_action');
        echo '<input type="hidden" name="cfp_do" value="add_note" />';
        echo '<input type="hidden" name="user_id" value="' . esc_attr((string)$user_id) . '" />';
        echo '<textarea name="note" rows="3" class="large-text" placeholder="' . esc_attr__('Add a private note...', 'classflow-pro') . '"></textarea><br/>';
        echo '<label><input type="checkbox" name="visible_to_user" value="1" /> ' . esc_html__('Visible to user', 'classflow-pro') . '</label> ';
        submit_button(__('Add Note', 'classflow-pro'), 'secondary', '', false);
        echo '</form>';
        echo '<table class="widefat striped"><thead><tr><th>' . esc_html__('Note', 'classflow-pro') . '</th><th>' . esc_html__('Visible', 'classflow-pro') . '</th><th>' . esc_html__('By', 'classflow-pro') . '</th><th>' . esc_html__('At (UTC)', 'classflow-pro') . '</th></tr></thead><tbody>';
        if (!$notes) echo '<tr><td colspan="4">' . esc_html__('No notes.', 'classflow-pro') . '</td></tr>';
        foreach ($notes as $n) {
            echo '<tr><td>' . wp_kses_post($n['note']) . '</td><td>' . ($n['visible_to_user'] ? 'Yes' : 'No') . '</td><td>' . esc_html($n['author'] ?: '-') . '</td><td>' . esc_html($n['created_at']) . '</td></tr>';
        }
        echo '</tbody></table>';

        // Intake forms
        $intake_tbl = $wpdb->prefix . 'cfp_intake_forms';
        $intakes = $wpdb->get_results($wpdb->prepare("SELECT * FROM $intake_tbl WHERE user_id = %d ORDER BY signed_at DESC", $user_id), ARRAY_A);
        echo '<h3>' . esc_html__('Intake Forms', 'classflow-pro') . '</h3>';
        if (!$intakes) {
            echo '<p>' . esc_html__('No intake forms on file.', 'classflow-pro') . '</p>';
        } else {
            echo '<table class="widefat striped"><thead><tr><th>' . esc_html__('Signed At (UTC)', 'classflow-pro') . '</th><th>' . esc_html__('Summary', 'classflow-pro') . '</th></tr></thead><tbody>';
            foreach ($intakes as $it) {
                $summary = '';
                $data = json_decode($it['data'] ?? '', true);
                if (is_array($data)) {
                    $summary = implode('; ', array_map(function($k,$v){ return $k . ': ' . (is_scalar($v)?$v:json_encode($v)); }, array_keys($data), $data));
                }
                echo '<tr><td>' . esc_html($it['signed_at']) . '</td><td>' . esc_html(mb_strimwidth($summary, 0, 160, '…')) . '</td></tr>';
            }
            echo '</tbody></table>';
        }

        // Quick links
        echo '<p style="margin-top:16px;">';
        echo '<a class="button" href="' . esc_url(admin_url('admin.php?page=classflow-pro-schedules')) . '">' . esc_html__('Open Schedules', 'classflow-pro') . '</a> ';
        echo '<a class="button" href="' . esc_url(admin_url('admin.php?page=classflow-pro-bookings')) . '">' . esc_html__('Open Bookings', 'classflow-pro') . '</a>';
        echo '</p>';
    }
}

